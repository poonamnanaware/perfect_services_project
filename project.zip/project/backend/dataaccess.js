import { Sequelize } from "sequelize";
import pkg from "sequelize";
import role from "./models/role.js";
import employees from "./models/employees.js"
import registration from "./models/registration.js";
import status from "./models/status.js";
import userinformation from "./models/userinformation.js";
const { DataTypes } = pkg;
import service from "./models/service.js";
import totalservices from "./models/totalservices.js";
import vehicleinfo from "./models/vehicleinfo.js";
import vehicletypes from "./models/vehicletypes.js";

const sequelize = new Sequelize("business", "poonam", "Blaze@123", {
  host: "localhost",
  port: 5432,
  dialect: "postgres",
});

const jwtSettings = {
  jwtSecret: "msit007700itms",
};

class AuthLogic {
  constructor() {

    employees.init(sequelize, DataTypes);
    role.init(sequelize, DataTypes);
    registration.init(sequelize, DataTypes);
    status.init(sequelize, DataTypes);
    userinformation.init(sequelize, DataTypes);
    service.init(sequelize, DataTypes);
    totalservices.init(sequelize, DataTypes);
  }

  
  async createUser(req, resp) {
    const user = req.body;
    console.log(JSON.stringify(req.body));
    await sequelize.sync({ force: false });

    const findUser = await userinformation.findOne({
      where: { email: user.email },
    });

    if (findUser !== null) {
      return resp
        .status(409)
        .send({ message: `User ${user.email} is already present` });
    }

    const userCreated = await userinformation.create({
      customername: user.customername,
      address: user.address,
      state: user.state,
      city: user.city,
      primarycontactnumber: user.primarycontactnumber,
      roleid: 5,
      email: user.email,
      userpassword: user.userpassword,
    });

    return resp
      .status(201)
      .send({ message: `User ${user.customername} is registered successfully` });
  }


  async loginUser(req, resp) {
    const user = req.body;
    await sequelize.sync({ force: false });

    const findUser = await userinformation.findOne({
      where: { email: user.email },
    });

    if (findUser === null) {
      return resp
        .status(401)
        .send({ message: `User ${user.email} is not found` });
    }

    if (findUser.userpassword.trim() !== user.password.trim()) {
      return resp
        .status(401)
        .send({ message: `User ${user.email} password does not match` });
    }

    return resp
      .status(200)
      .send({
        message: `User ${user.email} is authenticated successfully`,
        records: findUser,
        data: findUser
      });
  }

  async bookService(req, resp) {
    console.log("******************************************vehiclenumber*********************************************************");
  
    const serv = req.body;
    console.log(serv.vehiclenumber);
    console.log("********************************************vehiclenumber*******************************************************");
  
    if (serv != null) {
     
      await sequelize.sync({ force: false });
      const serviceBooked = await registration.create({
        vehiclenumber: serv.vehiclenumber, 
        customerid: serv.customerid,
        statusid: serv.statusid, 
        serviceid: serv.serviceId,
        serviceregistrationdate: new Date()
      });

      if (serviceBooked !== null) {
        const totalserv = await totalservices.create({
          vehicletypeid: 6,
          serviceid: 3,
          customerid: 2,

        });

        if (totalserv !== null) {
          console.log(totalserv);

        } else {

          return resp.status(409).send({ message: `No Data in Data base` });

        }

        return resp.status(201).send({ message: `User booked service successfully`, data: serviceBooked });

      } else {

        return resp.status(409).send({ message: `Incorrect Data` });

      }

    }

  }

  async getTotalServicesByCustomerId(req, resp) {

    console.log(req.params.custId);
    const customerId = parseInt(req.params.custId);
    let custstring = customerId;

    await sequelize.sync({ force: false });

    const servicesForCustomer = await totalservices.findAll({

      where: { customerid: parseInt(req.params.custId) },

    });

    if (servicesForCustomer !== null) {

      return resp.status(201).send({ message: `Data received`, data: servicesForCustomer });

    } else {

      return resp.status(409).send({ message: `Incorrect Data` });

    }

  }


  async getServices(req, resp) {
    const allServices = await service.findAll();
   console.log(allServices);
     if (allServices !== null) {

      return resp.status(201).send({ message: `Username and pass is correct`, data: allServices });

    } else {

      return resp.status(409).send({ message: `No Data in Data base` });

    }

  }

}

export default AuthLogic;
