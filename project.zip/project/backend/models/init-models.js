import _sequelize from "sequelize";
const DataTypes = _sequelize.DataTypes;
import _registration from  "./registration.js";
import _service from  "./service.js";
import _totalservices from  "./totalservices.js";
import _vehicleinfo from  "./vehicleinfo.js";
import _vehicletypes from  "./vehicletypes.js";

export default function initModels(sequelize) {
  const registration = _registration.init(sequelize, DataTypes);
  const service = _service.init(sequelize, DataTypes);
  const totalservices = _totalservices.init(sequelize, DataTypes);
  const vehicleinfo = _vehicleinfo.init(sequelize, DataTypes);
  const vehicletypes = _vehicletypes.init(sequelize, DataTypes);

  registration.belongsTo(service, { as: "service", foreignKey: "serviceid"});
  service.hasMany(registration, { as: "registrations", foreignKey: "serviceid"});
  totalservices.belongsTo(service, { as: "service", foreignKey: "serviceid"});
  service.hasMany(totalservices, { as: "totalservices", foreignKey: "serviceid"});
  registration.belongsTo(status, { as: "status", foreignKey: "statusid"});
  status.hasMany(registration, { as: "registrations", foreignKey: "statusid"});
  totalservices.belongsTo(userinformation, { as: "customer", foreignKey: "customerid"});
  userinformation.hasMany(totalservices, { as: "totalservices", foreignKey: "customerid"});
  service.belongsTo(vehicletypes, { as: "vehicletype", foreignKey: "vehicletypeid"});
  vehicletypes.hasMany(service, { as: "services", foreignKey: "vehicletypeid"});

  return {
    registration,
    service,
    totalservices,
    vehicleinfo,
    vehicletypes,
  };
}
