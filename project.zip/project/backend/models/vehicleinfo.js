import _sequelize from 'sequelize';
const { Model, Sequelize } = _sequelize;

export default class vehicleinfo extends Model {
  static init(sequelize, DataTypes) {
  return super.init({
    vehiclenumber: {
      type: DataTypes.STRING(100),
      allowNull: false,
      primaryKey: true
    },
    vehicletype: {
      type: DataTypes.STRING(100),
      allowNull: false
    }
  }, {
    sequelize,
    tableName: 'vehicleinfo',
    schema: 'public',
    timestamps: false,
    indexes: [
      {
        name: "vehicleinfo_pkey",
        unique: true,
        fields: [
          { name: "vehiclenumber" },
        ]
      },
    ]
  });
  }
}
