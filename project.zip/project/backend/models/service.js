import _sequelize from 'sequelize';
const { Model, Sequelize } = _sequelize;

export default class service extends Model {
  static init(sequelize, DataTypes) {
  return super.init({
    serviceid: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    servicename: {
      type: DataTypes.STRING(100),
      allowNull: false
    },
    vehicletypeid: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'vehicletypes',
        key: 'vehicletypeid'
      }
    },
    cost: {
      type: DataTypes.INTEGER,
      allowNull: false
    }
  }, {
    sequelize,
    tableName: 'service',
    schema: 'public',
    timestamps: false,
    indexes: [
      {
        name: "service_pkey",
        unique: true,
        fields: [
          { name: "serviceid" },
        ]
      },
    ]
  });
  }
}
