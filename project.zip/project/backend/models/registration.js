import _sequelize from 'sequelize';
const { Model, Sequelize } = _sequelize;

export default class registration extends Model {
  static init(sequelize, DataTypes) {
  return super.init({
    registrationid: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    vehiclenumber: {
      type: DataTypes.STRING(100),
      allowNull: false
    },
    customerid: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    workeridid: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    serviceleadid: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    servicemanagerid: {
      type: DataTypes.INTEGER,
      allowNull: true
    },
    serviceregistrationdate: {
      type: DataTypes.DATEONLY,
      allowNull: true
    },
    actualservicestartdate: {
      type: DataTypes.DATEONLY,
      allowNull: true
    },
    expectedserviceenddate: {
      type: DataTypes.DATEONLY,
      allowNull: true
    },
    actualserviceenddate: {
      type: DataTypes.DATEONLY,
      allowNull: true
    },
    statusid: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'status',
        key: 'statusid'
      }
    },
    serviceid: {
      type: DataTypes.INTEGER,
      allowNull: false,
      references: {
        model: 'service',
        key: 'serviceid'
      }
    }
  }, {
    sequelize,
    tableName: 'registration',
    schema: 'public',
    timestamps: false,
    indexes: [
      {
        name: "registration_pkey",
        unique: true,
        fields: [
          { name: "registrationid" },
        ]
      },
    ]
  });
  }
}
