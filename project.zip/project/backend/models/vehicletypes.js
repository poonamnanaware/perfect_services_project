import _sequelize from 'sequelize';
const { Model, Sequelize } = _sequelize;

export default class vehicletypes extends Model {
  static init(sequelize, DataTypes) {
  return super.init({
    vehicletypeid: {
      autoIncrement: true,
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    vehicletypename: {
      type: DataTypes.STRING(100),
      allowNull: false
    }
  }, {
    sequelize,
    tableName: 'vehicletypes',
    schema: 'public',
    timestamps: false,
    indexes: [
      {
        name: "vehicletypes_pkey",
        unique: true,
        fields: [
          { name: "vehicletypeid" },
        ]
      },
    ]
  });
  }
}
