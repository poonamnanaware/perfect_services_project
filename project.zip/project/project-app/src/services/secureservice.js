import axios from 'axios';


export default class SecureService {
    constructor(){
        this.url = 'http://localhost:7013';
    }

   
    createUser(user){
        console.log("sercureserv..................................................");
        console.log(JSON.stringify(user));
        console.log("sercureserv..................................................");
        let response = axios.post(`${this.url}/api/auth/register`, user, {
            headers:{
                'Content-Type': 'application/json'
            }
        });
        return response;
    }



    loginUser(email,password){

        let user = {"email":email, "password":password};

        let response = axios.post(`${this.url}/api/auth/loginUser`, user, {
            headers:{
                'Content-Type': 'application/json'
            }
        });
        return response;
    }


    // getServices(token){
    //     let response = axios.get(`${this.url}/api/getServices`, {
    //         headers:{
    //             "Authorization": `Bearer ${token}`
    //         }
    //     });
    //     return response;
    // }


    // bookService(vehicletypename,vehiclenumber,servicename){

    //     console.log("---------------Inside secureservice--------------------------");
    //     let user = {
    //         "vehicletypename": vehicletypename,
    //         "vehiclenumber": vehiclenumber,
    //         "servicename": servicename,
    //         "customerid": customerid,
    //         "statusid": statusid,
    //         "serviceid": serviceid

    //     }
      
    //    // let user = {"vehicletypename":vehicletypename, "vehiclenumber":vehiclenumber, "servicename":servicename };
    //     console.log(user);
    //     let response = axios.post(`${this.url}/api/bookService`, user, {
    //         headers:{
    //             'Content-Type': 'application/json'
    //         }
    //     });
    //     return response;
    // }

    // getdepartments(token){
    //     let response = axios.get(`${this.url}/api/auth/departments`, {
    //         headers:{
    //             "Authorization": `Bearer ${token}`
    //         }
    //     });
    //     return response;
    // }
     
}