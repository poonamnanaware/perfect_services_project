import React from 'react';
import { useState } from "react";
import { Button, Form, FormGroup, Label, Input, Span } from 'reactstrap';
import { useNavigate } from 'react-router-dom';
import { NavLink } from 'react-router-dom';
import "./../../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "./../../node_modules/bootstrap/dist/js/bootstrap.bundle.min.js";

const MenuComponent = () => {


    return (
        <>
        
            <NavLink exact  to = "/about">About Us</NavLink>
            <br></br>
            <NavLink exact  to = "/contact">Contact</NavLink>
         
        </>





    );
};

export default MenuComponent;