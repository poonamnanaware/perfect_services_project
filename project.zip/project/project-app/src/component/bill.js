import React from 'react';
import { useState } from "react";
import { Button, Form, FormGroup, Label, Input, Span } from 'reactstrap';
import { useNavigate } from 'react-router-dom';
import "./../../node_modules/bootstrap/dist/css/bootstrap.min.css";
//import "./../../node_modules/bootstrap/dist/js/bootstrap.bundle.min.js";

const BillComponent = () => {
    const navigate = useNavigate();

    return (
        <>
            
            <div class=" border border-dark bg-light">
            <h1 style={{ color: "white", fontSize: '5em', textAlign: 'center', backgroundColor: 'grey' }}>Perfect Services</h1>
            </div>
            <br></br>
            <Form className="login-form" action="" >
                <FormGroup>
                    <Label htmlFor="servicename">Service Name</Label>
                    <Input type="text" autoComplete='off'
                       // value={bookService.vehicletypename}
                        // onChange={(e)=>setVehicleNumber(e.target.value)}
                        name="servicename" id="servicename" placeholder="servicename"></Input>
                </FormGroup>
                <FormGroup>
                    <Label htmlFor="cost">Cost</Label>
                    <Input type="cost" autoComplete='off'
                       // value={bookService.vehiclenumber}
                        // onChange={(e)=>setVehicleType(e.target.value)}
                        name="cost" id="cost" placeholder="cost"></Input>
                </FormGroup>

                <FormGroup>
                    <Label htmlFor="totalcost">Total Cost</Label>
                    <Input type="totalcost" autoComplete='off'
                       // value={bookService.vehiclenumber}
                        // onChange={(e)=>setVehicleType(e.target.value)}
                        name="totalcost" id="totalcost" placeholder="totalcost"></Input>
                </FormGroup>

             


                <div className="text-center border border-light p-1 mb-1 ">
                    <button type="submit" className="btn btn-primary btn btn-space"
                        // onClick={
                        //     book
                        // }
                    >Generate Bill</button>
                      {/* <button className="btn btn-primary text-center btn btn-space" onClick={() => {
                        navigate('/bill')
                    }}>Pay Bill</button> */}
                    <button className="btn btn-primary text-center btn btn-space" onClick={() => {
                        navigate('/')
                    }}>Home</button>



                </div>

            </Form>

               
         
        </>





    );
};

export default BillComponent;