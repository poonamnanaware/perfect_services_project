import React from 'react';
import { useState } from "react";
import { Button, Form, FormGroup, Label, Input, Span } from 'reactstrap';
import { useNavigate } from 'react-router-dom';
import "./../../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "./../../node_modules/bootstrap/dist/js/bootstrap.bundle.min.js";

const ContactComponent = () => {
    const navigate = useNavigate();

    return (
        <>

<div class=" border border-dark bg-light">
            <h1 style={{ color: "white", fontSize: '5em', textAlign: 'center', backgroundColor: 'grey' }}> Perfect Services</h1>
            </div>
            <div class="feature-item">
                <h1>CALL US NOW AT</h1>
                <div class="icon sl-small-phone-circle">
                       
                </div>
                <p>
                    " Mobile: (520) 577 2710"
                    <br></br>
                    "Assistance: (520) 577 2725"
                    <br></br>
                    "Weekdays: (520) 577 7212 "
                </p>
            </div>
            <div>
            <button className="btn btn-primary text-center btn btn-space" onClick={()=> {
                        navigate('/')}}>Home</button>
            </div>
        </>





    );
};

export default ContactComponent;