import React from "react";
import { useNavigate } from "react-router-dom";
import "./../../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "./../../node_modules/bootstrap/dist/js/bootstrap.bundle.min.js";
import { NavLink } from "reactstrap";
import { Row } from "reactstrap";
import { Col } from "reactstrap";


const HomeComponent = () => {
    const navigate = useNavigate();


    return (

        //         <div style={{ padding: 100 }}>

        //             <div style={{ margin: 10 }}>
        //                 <h1 style={{ color: "white", fontSize: '5em', textAlign: 'center', backgroundColor: 'grey' }}>Perfect Services</h1></div>
        // <Nav>
        // <NavLink exact  to = "/about">About Us</NavLink>
        //             {/* <br></br> */}
        //             <NavLink exact  to = "/contact">Contact</NavLink>
        //             {/* <br></br> */}
        //             <NavLink exact  to = "/login">Log in</NavLink>
        //             {/* <br></br> */}
        //             <NavLink exact  to = "/signup">Signup</NavLink>
        // </Nav>


        //         </div>
        <>

<div style={{ margin: 10 }}>
                        <h1 style={{ color: "white", fontSize: '5em', textAlign: 'center', backgroundColor: 'grey' }}>Perfect Services</h1></div>

            <nav className="navbar navbar-expand-lg navbar-light bg-light">
                <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span className="navbar-toggler-icon"></span>
                </button>
                <div className="collapse navbar-collapse justify-content-end" id="navbarNav">
                    <ul className="navbar-nav">
                        <li className="nav-item active btn btn-primary fw-bold navbar-nav">
                            
                            <a className="nav-link" href="/login">Log in</a>
                        </li>
                        <li className="nav-item fw-bold btn btn-secondary navbar-nav">
                          
                            <a className="nav-link" href="/signup">Signup</a>
                        </li>
                        <li className="nav-item fw-bold btn btn-warning navbar-nav">
                        <a className="nav-link" href="/contact">Contact</a>
                        </li>
                        <li className="nav-item fw-bold btn btn-primary navbar-nav">
                        <a className="nav-link" href="/about">About Us</a>
                        </li>
                    </ul>
                </div>
            </nav>
        <div className="row">
            <div className="col-md-12">
                <div className="media">
                {/* <img src="images/img1.jpg" className="img-fluid" alt="..."></img> */}
                {/* <img src={"/assets/images/img1.jpg"} alt="logo"/> */}
                </div>
                <div class="image1">
      <img src='/assets/images/car_serv1.jpg' alt='pic' />
    </div>
            </div>
        
        </div>
        </>
    )
}
export default HomeComponent;