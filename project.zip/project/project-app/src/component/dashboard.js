import React from 'react';
import { useState } from "react";
import { Button, Form, FormGroup, Label, Input, Span } from 'reactstrap';
import { useNavigate } from 'react-router-dom';
import { Dropdown } from 'reactstrap';
import { ButtonDropdown } from 'reactstrap';
import SecureService from "./../services/secureservice";

const serv = new SecureService();
const DashboardComponent = () => {


    const navigate = useNavigate();

    const [vehicleNumber, setVehicleNumber] = useState("");

    const [vehicleType, setVehicleType] = useState("");

    const [vehicleNo, setVehicleNo] = useState("");

    // const [bookService, setBookService] = useState({
    //     vehicletypename: "",
    //     vehiclenumber: ""
    //    // servicename: ""
      

    // });

    const [records, setRecords] = useState([]);
    const [message, setMessage] = useState('');


    // const handleInput = (e) => {
    //     const name = e.target.name;
    //     const value = e.target.value;
    //    // console.log(name + value);
    //     setBookService({ ...bookService, [name]: value });

    // }

    // const submitForm = (e) => {
    //     e.preventDefault();
    //     const newRecord = { ...bookService, id: new Date().getTime().toString() };
    //     // alert(records);
    //     setRecords([...records, newRecord]);
    //     //console.log(records);
        
    //     console.log(JSON.stringify(records));
    // }

    const book = () =>{

        const obj = {

            vehicleNumber:vehicleNumber,
            customerId: 2,
            serviceId:1,
            vehicleType:'Bike',
            vehicleTypeId:1

        };

        bookAService(obj)

        // getTotalServicesByCustomerId("2");   
     }

    const bookAService = (bookService) => {

        console.log(bookService)

        fetch("http://localhost:7013/api/bookService", {

            method: "POST",

            body: JSON.stringify({

                vehiclenumber: bookService.vehicleNumber,
                customerid: bookService.customerId,
                statusid: 1,
                serviceId: bookService.serviceId,
                vehicletype: bookService.vehicleType,
                vehicleTypeId: bookService.vehicleTypeId,

            }),

            headers: {

                "Content-type": "application/json; charset=UTF-8"

            }

        })

            .then(response => response.json())

            .then(json => {
               // console.log(json);
                alert("User booked service successfully");

            });
    }

    
//   const getResponse=()=>{
//     // read token from sessionStorage
//     const token = sessionStorage.getItem('token');  
//     // passing token to HTTP Call
//     serv.getServices(token).then((response)=>{
//         setMessage(response.data.message);
//         setDepartments(response.data.records);    
//     }).catch((error)=>{
//         setMessage(error);
//     });
//   };
    
    return (
        <>
        <div class=" border border-dark bg-light">
        <h1 style={{ color: "white", fontSize: '5em', textAlign: 'center', backgroundColor: 'grey' }}> Perfect Services</h1>
        </div>
            <Form className="login-form" action="" >
                <FormGroup>
                    <Label htmlFor="vehicleType">Vehicle Number</Label>
                    <Input type="text" autoComplete='off'
                       // value={bookService.vehicletypename}
                        onChange={(e)=>setVehicleNumber(e.target.value)}
                        name="vehicleType" id="vehicleType" placeholder="vehicleType"></Input>
                </FormGroup>
                <FormGroup>
                    <Label htmlFor="vehicleType">Vehicle Type</Label>
                    <Input type="vehicleType" autoComplete='off'
                       // value={bookService.vehiclenumber}
                        onChange={(e)=>setVehicleType(e.target.value)}
                        name="vehicleType" id="vehicleType" placeholder="vehicleType"></Input>
                </FormGroup>

                <FormGroup>

                    <Label htmlFor="serviceType" className="form-label">Service Type</Label>
                    <select id="serviceType" className="form-select">
                        <option selected>Select Service Type</option>
                        <option value="maharashtra">Washing</option>
                        <option value="Kerala">Oiling</option>
                        <option value="gujrat">Part Change</option>
                        <option value="telangana">Cleaning</option>

                    </select>
                </FormGroup>


                <div className="text-center border border-light p-1 mb-1 ">
                    <button type="submit" className="btn btn-primary btn btn-space"
                        onClick={
                            book
                        }
                    >Book Service</button>
                      <button className="btn btn-primary text-center btn btn-space" onClick={() => {
                        navigate('/bill')
                    }}>Pay Bill</button>
                    <button className="btn btn-primary text-center btn btn-space" onClick={() => {
                        navigate('/')
                    }}>Home</button>



                </div>

            </Form>

            {/* <>
                <Form className="login-form" action="" onSubmit={submitForm} >
                    <FormGroup>
                        <Label htmlFor="vehicleType">Vehicle Type</Label>
                        <Input type="text" autoComplete='off'
                            value={bookService.vehicletypename}
                               onChange={handleInput}
                            name="vehicleType" id="vehicleType" placeholder="vehicleType"></Input>
                    </FormGroup>
                    <FormGroup>
                        <Label htmlFor="vehicleNumber">Vehicle Number</Label>
                        <Input type="vehicleNumber" autoComplete='off'
                            value={bookService.vehiclenumber}
                            onChange={handleInput}
                            name="vehicleNumber" id="vehicleNumber" placeholder="vehicleNumber"></Input>
                    </FormGroup>
                    <FormGroup>


                        <Label htmlFor="serviceType" className="form-label">Service Type</Label>
                        <select id="serviceType" className="form-select">
                            <option selected>Select Service Type</option>
                            <option value="maharashtra">Washing</option>
                            <option value="Kerala">Oiling</option>
                            <option value="gujrat">Part Change</option>
                            <option value="telangana">Cleaning</option>

                        </select>
                    </FormGroup>


                    <div className="text-center border border-light p-1 mb-1 ">
                        <button type="submit" className="btn btn-primary btn btn-space"
                         onClick={ 
                            bookServices
                         }
                        >Book Service</button>
                        <button className="btn btn-primary text-center btn btn-space" onClick={() => {
                            navigate('/')
                        }}>Home</button>



                    </div>

                </Form>

            </> */}
        </>



    );
};

export default DashboardComponent;