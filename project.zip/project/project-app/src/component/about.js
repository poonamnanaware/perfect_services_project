import React from 'react';
import { useState } from "react";
import { Button, Form, FormGroup, Label, Input, Span } from 'reactstrap';
import { useNavigate } from 'react-router-dom';
import "./../../node_modules/bootstrap/dist/css/bootstrap.min.css";
//import "./../../node_modules/bootstrap/dist/js/bootstrap.bundle.min.js";

const AboutComponent = () => {
    const navigate = useNavigate();

    return (
        <>
            
            <div class=" border border-dark bg-light">
            <h1 style={{ color: "white", fontSize: '5em', textAlign: 'center', backgroundColor: 'grey' }}>Welcome To Perfect Services</h1>
            </div>
            <br></br>
<div class="text-dark text-center text-wrap font-weight-bold font-italic">
<p>

Welcome to Guaranteed Automotive and Transmission Service, 
your head pick for master vehicle fix close and around Lafayette, IN. 
Our very educated ASE-Certified auto mechanics really have an enthusiasm for
 playing out a wide range of vehicle fix administrations, huge or little.</p>
</div>
      <div>
      <button className="btn btn-primary text-center btn btn-space" onClick={()=> {
                        navigate('/')}}>Home</button>
            </div>
               
         
        </>





    );
};

export default AboutComponent;