import logo from './logo.svg';
import './App.css';
import LoginFormComponent from "./component/loginform"
import {BrowserRouter as Router} from 'react-router-dom';
import "./../node_modules/bootstrap/dist/css/bootstrap.min.css";
import SignUpComponent from "./component/signup";
import { Route, Routes } from "react-router";
import DashboardComponent from "./component/dashboard";
import MenuComponent from "./component/menu";
import AboutComponent from "./component/about";
import ContactComponent from './component/contact';
import HomeComponent from "./component/home";
import BillComponent from "./component/bill";

function App() {
  const PageNotFound = () =>(
    <div>
      404!
    </div>
  )

  
  return (

  
    <Router>
    
      <Routes>
      <Route exact path ="/" element={<HomeComponent/>}></Route>
        <Route exact path ="/contact" element={<ContactComponent/>}></Route>
        <Route exact path ="/login" element={<LoginFormComponent/>}></Route>
        <Route exact path ="/signup" element={<SignUpComponent/>}></Route>
        <Route exact path ="/dashboard" element={<DashboardComponent/>}></Route>
        <Route exact path ="/about" element={<AboutComponent/>}></Route>
        <Route exact path ="/contact" element={<ContactComponent/>}></Route>
        <Route exact path ="/bill" element={<BillComponent/>}></Route>
        
        <Route  element={<PageNotFound/>}></Route>

      </Routes>
    </Router>
  );
}

export default App;
